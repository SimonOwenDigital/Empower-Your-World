# Licence and use

**Free to use and adapt.**

This Governed AI Production Starter Kit is offered free of charge. You may use it, copy it, change it, and build on it for any purpose, personal or commercial. Fill the templates with your own content, tune the rubric to your domain, write your own skills from the example — it is yours to run with.

**Attribution appreciated.**

If the kit helps you, a mention of [empoweryour.world](https://empoweryour.world) is appreciated but not required. If you adapt and share it onward, a note pointing back to the original is a kind thing to do.

**No warranty.**

The kit is provided "as is", without warranty of any kind, express or implied. It is a starting scaffold, not a guarantee of any outcome. You are responsible for what you build with it and for checking it fits your own context, standards and obligations. The author accepts no liability for any loss or damage arising from its use.

---

*Brought to you by [empoweryour.world](https://empoweryour.world).*
