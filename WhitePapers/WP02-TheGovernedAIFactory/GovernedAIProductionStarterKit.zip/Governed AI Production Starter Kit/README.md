# Governed AI Production Starter Kit

*A free, reusable scaffolding for running your own AI production line as a governed system.*

---

## What this is

This kit gives away the **method** behind a governed AI production line: the way of working that lets a small team (or a single person working with AI) produce a large, consistent body of assets without quality drifting, work colliding, or the system quietly rotting over time.

It is deliberately **generic and empty**. There is no proprietary content here, no models, no house voice. What you get is the reusable scaffolding and the working practices, ready for you to fill with your own material. Think of it as the empty factory and its operating manual, not the products that come off the line.

## Who it is for

- Anyone running an AI-assisted content or asset production line and watching consistency slip as volume grows.
- Small teams and solo operators who want the discipline of a larger operation without the overhead.
- Anyone who wants their AI tooling to behave like a governed system rather than a pile of one-off prompts.

## The core idea

Run your AI production line as a **governed system**, built on four pillars:

1. **A single source of truth.** One canonical document that holds your taxonomy, your structure, your standards and your change log. Everything derives from it; when something changes, you change it here first. (See `source-of-truth-template.md`.)
2. **A quality gate.** A shared rubric that scores every asset on the same dimensions, so "good" means the same thing every time and refresh is driven by measured gaps, not opinion. (See `quality-rubric.md`.)
3. **Dashboards.** A live view of where every asset sits against the bar, and what each unit of work costs you. (See `quality-heatmap-template.xlsx` and `cost-ledger-template.xlsx`.)
4. **A clear human-in-the-loop boundary.** The machine drafts, scores, reconciles and reports; the human decides, approves and owns the voice and the judgement calls. The boundary is explicit, not accidental.

## How the pieces fit

```
        Single source of truth  ───────────────►  Standards + structure for everything
   (source-of-truth-template.md)                          │
                                                          ▼
        Skills (repeatable actions) ──────────►  Produce + score assets
   (example-skill__asset-quality-audit/)                  │
                                                          ▼
        Quality rubric  ──────────────────────►  The shared bar for "good"
        (quality-rubric.md)                               │
                                                          ▼
        Dashboards  ──────────────────────────►  Where every asset sits + what it costs
   (quality-heatmap-template.xlsx,                        │
    cost-ledger-template.xlsx)                            ▼
        Human-in-the-loop  ───────────────────►  Decide, approve, own the voice
```

The source of truth sets the standards. Skills are the repeatable actions that build and check assets against those standards. The rubric is the shared definition of "good" that the audit skill applies. The dashboards make quality and cost visible. The human stays in the loop at every approval point.

## Five-step quickstart

1. **Stand up your source of truth.** Copy `source-of-truth-template.md`, rename it, and fill in your own taxonomy, tiers and standards. This is now the document everything else derives from.
2. **Adopt the quality rubric.** Take `quality-rubric.md` as-is or tune the dimension descriptions to your domain. Agree the grade bands with whoever owns quality.
3. **Open the dashboards.** Drop your assets into `quality-heatmap-template.xlsx` and start logging spend in `cost-ledger-template.xlsx`. Even a few rows make the system visible.
4. **Run the example skill.** Use `example-skill__asset-quality-audit/SKILL.md` to score one real asset against the rubric. Read the overall score, the grade, the weakest dimension and the prioritised fixes.
5. **Close the loop.** Fix the weakest dimension, re-score, update the heatmap, and log the cost. Repeat. Refresh is now driven by the gap to the bar, not by guesswork.

## Going further

- **The full field report.** For the thinking behind all of this, read the field report *The Governed AI Factory* at **[empoweryour.world](https://empoweryour.world)**.
- **Write your own skills.** `write-your-own-skill-guide.md` shows how to tell a Skill from a Reference from a Template, and how to author a tight SKILL.md of your own.
- **Licence.** Free to use and adapt. See `LICENSE-and-use.md`.

---

*Brought to you by [empoweryour.world](https://empoweryour.world). If this kit helps, a mention is appreciated.*
