# Write Your Own Skill — a short guide

*Three things make a governed AI production line repeatable: **Skills**, **References** and **Templates**. They are easy to confuse, and confusing them is why AI work drifts. This guide draws the line between them, says when to reach for each, and shows how to author a tight skill of your own — using the Asset Quality Audit skill in this kit as the worked example.*

---

## Skill vs Reference vs Template

| | **Skill** | **Reference** | **Template** |
|---|---|---|---|
| **What it is** | A repeatable action that needs judgement | Facts and standards that must stay consistent | A fixed form you build from |
| **It answers** | "How do I *do* this?" | "What is *true / the standard*?" | "What *shape* should it take?" |
| **It contains** | A method, triggers, an output shape | Definitions, rules, taxonomies, values | Empty structure with placeholders |
| **It changes** | When the method improves | When a fact or standard changes | When the standard form changes |
| **Example here** | `example-skill__asset-quality-audit` | `quality-rubric.md` | `source-of-truth-template.md`, the two `.xlsx` files |

The three work together. In this kit:

- The **rubric** (`quality-rubric.md`) is a **Reference** — the eight dimensions and grade bands, the facts that must stay consistent everywhere.
- The **audit** (`example-skill__asset-quality-audit/SKILL.md`) is a **Skill** — the repeatable action of *applying* that rubric with judgement to produce a score and a fix list.
- The **heatmap and source-of-truth files** are **Templates** — fixed forms you fill in.

A good rule of thumb: **if it needs judgement to run, it is a Skill. If it must never drift, it is a Reference. If you fill it in, it is a Template.**

## When to use each

- **Reach for a Reference** when there is a single right answer that everything must agree on — a taxonomy, a rubric, a set of brand values, a glossary. Write it once; point everything at it. Never copy its contents into a Skill, or the two will drift.
- **Reach for a Template** when the *shape* repeats but the *content* differs each time — a document layout, a spreadsheet, a canonical doc structure. Keep it empty and generic.
- **Reach for a Skill** when there is a repeatable *action* that needs judgement to perform well — scoring, restructuring, drafting in a voice, reconciling. The Skill carries the method; it *reads* References and *fills* Templates, but it is neither.

## How to author a simple skill

A Skill is a single `SKILL.md` file. Keep it tight — a skill that tries to do everything triggers on nothing and is trusted by no one.

### 1. Frontmatter: name + description

```
---
name: asset-quality-audit
description: Scores any asset against the eight-dimension quality rubric and turns
  the score into prioritised fixes. Use when someone says "score this", "audit
  this", "how good is this". Do NOT use to build or edit an asset.
---
```

The **name** is short and kebab-case. The **description** is the most important line you will write: it is what the system matches against to decide whether to fire the skill. Pack it with the **real trigger phrases** a user would actually say, and state clearly what the skill does *not* cover. Notice the audit skill's description lists "score this", "audit this", "how good is this" and explicitly rules out building or editing — that boundary stops it firing on the wrong jobs.

### 2. Trigger guidance

Right after the frontmatter, say in a sentence or two **when to use** and **when not to use** the skill. The audit skill does this: use it to *assess*, not to *build*; if the user wants the asset created, hand back. Clear boundaries are what make a skill safe to trust.

### 3. The method

A numbered procedure the skill follows every time. The audit skill's method is seven steps: read the whole asset, score each dimension with one line of evidence, compute the overall, assign the band, find the weakest, rank the fixes by gap, stop at assessment. Each step is concrete and checkable. If a step needs a fact or a standard, point at the **Reference** rather than restating it.

### 4. A fixed output shape

Show exactly what the skill returns. The audit skill prints a fixed block — overall, grade, eight dimension lines, weakest dimension, ranked fixes. A defined output shape makes a skill's results consistent and easy to feed into the next step (here, into the heatmap dashboard).

### Keeping it tight

- **One job per skill.** If you find yourself writing "and also…", that is a second skill.
- **Point, don't copy.** Read your References; never paste their contents in. One source of truth.
- **Triggers earn their keep.** Every phrase in the description should be something a real user would actually say.
- **Leave the human in the loop.** A good skill assesses, drafts or proposes; the human approves. Say so explicitly, as the audit skill does in its final step.

---

*Use the Asset Quality Audit skill as your template for skill number two. Copy its shape, swap in your method, and keep it tight.*
