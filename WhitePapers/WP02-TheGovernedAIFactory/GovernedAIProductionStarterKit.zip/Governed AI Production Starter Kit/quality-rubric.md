# Quality Rubric — the shared bar for "good"

*A generic, reusable rubric for scoring any asset on the same eight dimensions, every time. Adopt it as-is or tune the descriptions to your domain — but keep the dimensions and the bands stable, so a score means the same thing across the whole production line.*

---

## How it works

Score each asset on **eight dimensions**, each out of 100. The **overall score** is the (rounded) mean of the eight. The overall maps to a **grade band**. A dimension that scores below the bar is a **work item**, and the size of the refresh is driven by the **gap** — how far below "good" it sits — not by opinion or recency.

## The eight dimensions

### 1. Craft & Conformance
*Does it meet the standard for its type?* Measures whether the asset follows the structure, styling and required elements defined for its type in the source of truth. **Good** looks like: on-template, no structural gaps, nothing that would fail a conformance check.

### 2. Flow & Journey
*Does it take the reader/user somewhere, in the right order?* Measures the logical progression — setup, build, payoff — and the absence of dead ends, repetition or bloat. **Good** looks like: a clear arc, tight length, each part earning its place.

### 3. Relevance & Depth
*Is it about the right things, at the right depth?* Measures whether the content is on-topic and goes deep enough to be genuinely useful, without padding. **Good** looks like: the important points covered substantively; nothing essential missing; no filler.

### 4. Connectedness & Reuse
*Is it wired into the rest of the system?* Measures cross-links to sibling assets, shared components reused rather than reinvented, and a single shared source per fact. **Good** looks like: related assets referenced both ways; no orphaned, standalone duplication.

### 5. Voice & POV
*Does it sound like one consistent, opinionated author?* Measures consistency of voice and the presence of a clear point of view, free of generic or AI-tell phrasing. **Good** looks like: a recognisable, consistent voice that takes a position and defends it.

### 6. Currency & Alignment
*Is it up to date and aligned with the current standard?* Measures whether facts, references and terminology are current, and whether the asset matches the latest version of its type standard and its siblings. **Good** looks like: nothing stale; aligned to the current standard; versions in step.

### 7. Actionability & Grounding
*Can the reader actually do something with it, and is it grounded?* Measures whether claims are anchored to real evidence/standards and whether the asset tells the reader what to do next. **Good** looks like: concrete, grounded guidance; verifiable sources; a clear "so what / what next".

### 8. Accessibility
*Can everyone use it?* Measures born-accessible basics: alt text on non-decorative visuals, marked table headers, sufficient contrast, meaning carried in text not colour alone, descriptive links, adequate text size. **Good** looks like: meets the accessibility baseline at creation, not as an afterthought.

## Grade bands

| Band | Overall score | Meaning |
|---|---|---|
| **Excellent** | >= 85 | At or above the bar. Ship it. |
| **Good** | 70–84 | Solid; minor work items only. |
| **Needs Work** | 50–69 | Below the bar; has real gaps to close. |
| **Poor** | < 50 | Well below the bar; rework. |

## The refresh rule

**A score below the bar is a work item.** The bar is **Good (70)** for any dimension and **Excellent (85)** for assets you want at the top of the line. When a dimension scores below the bar, that becomes a prioritised task, and **the refresh is driven by the gap** — fix the weakest, largest-gap dimension first, re-score, and move on. This keeps maintenance objective: you refresh what is measurably behind, not what merely feels old.

---

*This rubric is the shared definition of "good" that the **Asset Quality Audit** skill applies (see `example-skill__asset-quality-audit/SKILL.md`) and that the **quality heatmap** dashboard tracks (see `quality-heatmap-template.xlsx`). The eight dimensions and the four bands are identical across all three — keep them in step if you tune them.*
