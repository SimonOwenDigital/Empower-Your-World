---
name: asset-quality-audit
description: Scores any asset against the eight-dimension quality rubric and turns the score into prioritised, actionable fixes. Use when someone says "score this", "audit this asset", "quality-check this", "how good is this", "rate this", or asks which assets need work. Produces an overall score out of 100, a grade band, a per-dimension breakdown, the weakest dimension, and a ranked list of fixes. Do NOT use to build or edit an asset, only to assess one.
---

# Asset Quality Audit

A reusable skill that scores any asset against the eight-dimension quality rubric and turns the result into prioritised work. It tells you **how good an asset is**, **where it is weakest**, and **what to fix first**.

## When to use this skill

Trigger when the user wants an asset assessed rather than built. Typical phrasings: "score this deck", "audit this doc", "quality-check this", "how good is this", "rate this", "which of these needs work". If the user wants the asset *created or edited*, this is the wrong skill — hand back to a build skill.

## What it needs

- **The asset** to score (or a clear pointer to it).
- **The rubric** — the eight dimensions and grade bands (see `../quality-rubric.md`).
- **The standard for the asset's type** — ideally from your source of truth, so Craft & Conformance and Currency & Alignment can be judged against a real spec. If no standard is available, score those dimensions on general best practice and say so.

## The eight dimensions

Score each out of 100. (Full descriptions live in `../quality-rubric.md` — keep them in step.)

1. **Craft & Conformance** — meets the standard for its type.
2. **Flow & Journey** — takes the reader somewhere, in the right order.
3. **Relevance & Depth** — right things, right depth, no filler.
4. **Connectedness & Reuse** — wired into the rest of the system.
5. **Voice & POV** — one consistent, opinionated author.
6. **Currency & Alignment** — up to date and aligned to the current standard.
7. **Actionability & Grounding** — usable and evidence-grounded.
8. **Accessibility** — born-accessible basics met.

## Method

1. **Read the whole asset first.** Do not score on a skim. Note what type it is and find its standard.
2. **Score each of the eight dimensions out of 100.** For each, write one short sentence of evidence — the specific thing that earned or lost the marks. Be honest; a generous score hides the work.
3. **Compute the overall** as the rounded mean of the eight dimension scores.
4. **Assign the grade band** from the overall:
   - **Excellent** >= 85
   - **Good** 70–84
   - **Needs Work** 50–69
   - **Poor** < 50
5. **Identify the weakest dimension** — the lowest score (break ties by largest gap to the bar, then by reader impact).
6. **Turn gaps into a prioritised fix list.** Every dimension below the bar (70) becomes a work item. Rank the items by **gap size first** (largest gap = highest priority), then by effort. Each fix is one concrete, doable action — not "improve flow" but "cut the three repeated setup paragraphs and merge sections 2 and 3".
7. **Stop at assessment.** Do not rewrite the asset unless explicitly asked. Offer to apply the top fixes as a separate step.

## Output format

Return exactly this shape:

```
ASSET: [name / identifier]
TYPE: [asset type]   STANDARD: [standard used, or "general best practice"]

OVERALL: [NN]/100  —  GRADE: [Excellent | Good | Needs Work | Poor]

DIMENSIONS
  1. Craft & Conformance      [NN]  — [one-line evidence]
  2. Flow & Journey           [NN]  — [one-line evidence]
  3. Relevance & Depth        [NN]  — [one-line evidence]
  4. Connectedness & Reuse    [NN]  — [one-line evidence]
  5. Voice & POV              [NN]  — [one-line evidence]
  6. Currency & Alignment     [NN]  — [one-line evidence]
  7. Actionability & Grounding[NN]  — [one-line evidence]
  8. Accessibility            [NN]  — [one-line evidence]

WEAKEST DIMENSION: [name] ([NN], [gap] below the bar)

PRIORITISED FIXES
  1. [largest-gap fix — one concrete action]
  2. [next fix]
  3. [next fix]
```

## Keep it honest

- Score against the **real standard** where you have one; say so when you don't.
- One line of **evidence** per dimension — a score with no reason is a guess with a number on it.
- A fix list with no priority order is just a wish list. **Rank by gap.**
- The audit **assesses**; it does not silently rewrite. The human stays in the loop on changes.
