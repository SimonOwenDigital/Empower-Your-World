WELCOME TO J01 PUBLIC
J01 Make AI Adoption Safe

1. Open 00_START_HERE.pdf first.

2. Your learning materials are in the numbered folders:

   01_Journey_Guide          Public Journey Guide
   02_Journey_Deck           Public Journey Deck
   03_Summary                Public Summary
   04_Risk_Spine_Model       Risk Spine public model
   05_Module_Cards           Six Module Cards
   06_L0_Journey_Check       L0 Journey Check (a private reflection you can write in)
   07_Where_to_Go_Next       Where to Go Next
   08_Module_Knowledge       The six module decks behind the stages, knowledge slides only
   09_Module_Reference       Law and standards behind the stages, in plain language

3. Read the use boundary in 00_START_HERE before you use any material.

4. You may keep, present and share these materials unmodified, with
   attribution to Simon Owen / EmPOWER Your World.

Version: RP-PUBLIC v2 (build 27 October 2026)
