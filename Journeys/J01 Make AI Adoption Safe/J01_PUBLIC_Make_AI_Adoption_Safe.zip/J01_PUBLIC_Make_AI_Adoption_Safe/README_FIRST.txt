WELCOME TO J01 PUBLIC
J01 Make AI Adoption Safe

1. Open 00_START_HERE.pdf first.

2. Keep 00_START_HERE.docx if you want an editable copy.

3. Your learning materials are in the numbered folders:

   01_Journey_Guide          Public Journey Guide
   02_Journey_Deck           Public Journey Deck
   03_Summary                Public Summary
   04_Risk_Spine_Model       Risk Spine public model
   05_Module_Cards           Six Module Cards
   06_L0_Journey_Check       L0 Journey Check
   07_Where_to_Go_Next       Where to Go Next
   08_Web_and_Blog_Bridge    Web and Blog Bridge

4. Read the use boundary in 00_START_HERE before you use any material.

Status: FINAL
Release date: 29 September 2026
