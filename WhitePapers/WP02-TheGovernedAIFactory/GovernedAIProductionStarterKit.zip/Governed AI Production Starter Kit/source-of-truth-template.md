# [PROGRAMME NAME] — Source of Truth

*Canonical single source of truth for [PROGRAMME / PRODUCTION LINE NAME]. **Maintain this file.** Everything else derives from it — when the structure changes, update this document first, then re-sync anything that summarises it. Last reviewed: [YYYY-MM-DD] ([one-line note on what changed]).*

---

> **How to use this template.** This is a generic, empty skeleton modelled on a proven pattern: one canonical document that holds your taxonomy, your structure, your standards, your working practices and your change log. Replace every `[PLACEHOLDER]` and the guidance notes in *italics* with your own content. Keep it as **one file** — the value is that there is a single place to look. Edit it surgically (change only what you mean to change) so parallel work does not clobber it.

---

## 1. Asset taxonomy — the organising key

*This section names every kind of thing your production line makes, and the one key that ties related assets together. The discipline that pays off: give every asset for the same topic the **same number**, so a family is obvious at a glance.*

- **Shared key.** Every asset for a topic shares the same [number / code]. Example: topic [NN] is `[Type][NN]` across all its types.
- **Type letters.** Define a short letter for each asset type so filenames self-describe. Fill in your own:

  | Letter | Type | What it is |
  |---|---|---|
  | [A] | [Type name] | [one-line description] |
  | [B] | [Type name] | [one-line description] |
  | [C] | [Type name] | [one-line description] |
  | [D] | [Type name] | [one-line description] |
  | [E] | [Type name] | [one-line description] |

- **Filename pattern.** `[Type][NN] [PREFIX] - [Title] v[N.N].[ext]` — e.g. `[A01 PREFIX - Title v1.0.ext]`. *(Add a suffix convention for internal-only assets if you need one.)*
- **Folder convention.** *State where the library lives and how it is laid out — e.g. one folder per topic family, plus a shared/overarching folder for cross-cutting assets.*
  - `[00 Overarching/]` — *cross-cutting assets that apply across the whole line.*
  - `[NN Topic/]` — *one folder per topic family, holding every asset that shares that number.*
- **Aspirational vs built.** *Note which types exist today and which are defined-but-not-yet-built, so the taxonomy can grow without being a to-do list.*

## 2. Structure / Tiers — do not conflate your axes

*Most production lines have more than one "size" or "level" vocabulary, and confusing them causes endless trouble. Name each axis explicitly and say which one you mean every time.*

- **[Axis 1 — e.g. roadmap tiers]:** [PLACEHOLDER — what it orders, e.g. which assets sit where].
- **[Axis 2 — e.g. risk / complexity classification]:** [PLACEHOLDER].
- **[Axis 3 — e.g. sizing]:** [PLACEHOLDER].

*Guidance: keep this list short. Three axes is usually plenty. The point is that "[tier]" never means two things in the same sentence.*

### Live structure map

*The single place your status lives. Update it here as things ship. One row per unit; bump the version column in lockstep with the actual asset.*

| [Unit] | Status | Version |
|---|---|---|
| [Unit 01 name] | [Planned / In build / Shipped] | [v0.1] |
| [Unit 02 name] | [Planned / In build / Shipped] | [v0.1] |
| [Unit 03 name] | [Planned / In build / Shipped] | [v0.1] |

*Status key: **Planned / In build / Shipped**. This is the **single** place statuses live — do not duplicate them elsewhere.*

## 3. Asset-type standards

*For each asset type, capture the standard it must meet: structure, required sections, styling, accessibility. A new asset of that type is built to this spec; an audit scores against it. Name a "source pattern" — the one existing asset that best embodies the standard — so there is always a worked reference.*

### [Type A] — [name] · source pattern: [the exemplar asset]
- **Structure.** [PLACEHOLDER — the canonical section order or layout].
- **Required elements.** [PLACEHOLDER — what every asset of this type must carry].
- **Styling.** [PLACEHOLDER — fonts, colours, chrome, or a pointer to a shared template].
- **Accessibility.** [PLACEHOLDER — the baseline every asset meets: alt text, header rows, contrast, meaning carried in text not colour alone].

### [Type B] — [name] · source pattern: [the exemplar asset]
- [PLACEHOLDER — repeat the shape above for each type.]

### [Type C] — [name] · source pattern: [the exemplar asset]
- [PLACEHOLDER.]

*Guidance: when a standard changes, change it here once. Mark clearly which version of the standard is current and which is retired, so an asset built to the old spec is a known refresh item, not a surprise.*

## 4. Deliverable bundle — what ships together

*When a unit reaches a final version, which assets must exist alongside it? Define the default bundle so completeness is checkable.*

- **[Type A]** — [the trigger asset]. *(always)*
- **[Type B]** — [companion]. *(always)*
- **[Type C]** — [companion]. *(conditional — when [criterion])*
- **[Type D]** — [companion]. *(conditional — assess first)*

## 5. Working practices

*The operating rules that keep the line healthy. These are the habits, not the artefacts.*

- **Draft-then-approve loop.** *The machine drafts; the human reviews and approves before anything is treated as final. Spell out the hand-off: what the AI may produce unprompted, and what always needs a human yes. Keep the boundary explicit — this is the human-in-the-loop control.*
- **Batched reconciliation pass.** *Derived/reference artefacts (dashboards, overview summaries, snapshots) are the main collision source. Do not refresh them on every change — batch them into a single consolidated pass run when nothing else is in flight.*
- **Parallel-working etiquette.** *Say which areas are safe to work on simultaneously and which are shared and must be edited carefully. For shared files (this source of truth, any overview, the dashboards): edit surgically, re-read immediately before each edit, change only your own rows, and never do a whole-file restage that clobbers others' work.*
- **Library is the system of record.** *The current version of every asset lives in the library, not in a transient working folder. Promote finished work back, bump the version (here too), and archive the superseded copy.*
- **[Your own practice].** [PLACEHOLDER.]

## 6. Voice & writing rules

*If your output has a house style, anchor it here (or point to a dedicated voice reference). Generic starting rules:*

- [PLACEHOLDER — language variant, e.g. UK / US English.]
- [PLACEHOLDER — tone and point-of-view stance.]
- [PLACEHOLDER — terminology decisions: the agreed term for a thing, and the retired alternatives.]
- [PLACEHOLDER — typographic rules, e.g. smart quotes, no em-dashes.]

## 7. Principles

*The handful of beliefs the whole line is built on. Keep it to a few lines.*

- [PLACEHOLDER — principle 1.]
- [PLACEHOLDER — principle 2.]
- [PLACEHOLDER — principle 3.]

## 8. Change log

*Append-only. Every substantive change to the structure, standards or working practices gets a dated note here. This is how the system stays honest about its own history — and how anyone (human or AI) catches up on what changed and why.*

- *[YYYY-MM-DD] — [what changed, in one or two sentences. Name the decision and the reason, not just the edit.]*
- *[YYYY-MM-DD] — [PLACEHOLDER.]*
- *[YYYY-MM-DD] — [PLACEHOLDER.]*
